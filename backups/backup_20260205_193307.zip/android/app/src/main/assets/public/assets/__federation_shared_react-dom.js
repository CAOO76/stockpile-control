import{i as f}from"./index2.js";export{f as default};
