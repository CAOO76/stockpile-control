import"./vendor-extra.js";import{A as a}from"./__federation_expose_Plugin.js";export{a as default};
