package com.minreport.stockpilecontrol;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
