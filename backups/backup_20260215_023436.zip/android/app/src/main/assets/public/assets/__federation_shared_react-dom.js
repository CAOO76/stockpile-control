import"./vendor-extra.js";import{a as t}from"./vendor-react.js";export{t as default};
