import"./vendor-extra.js";import{i as a}from"./vendor-react.js";export{a as default};
