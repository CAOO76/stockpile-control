import{r as e}from"../index.esm2017.js";import{F as i,S as n,D as t,_,a as m,b as v,c as A,d as g,e as d,f as l,g as S,h as b,i as c,j as E,k as F,l as f,m as C,n as L,o as D,p as N,s as O}from"../index.esm2017.js";var s="firebase",a="10.14.1";/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */e(s,a,"app");export{i as FirebaseError,n as SDK_VERSION,t as _DEFAULT_ENTRY_NAME,_ as _addComponent,m as _addOrOverwriteComponent,v as _apps,A as _clearComponents,g as _components,d as _getProvider,l as _isFirebaseApp,S as _isFirebaseServerApp,b as _registerComponent,c as _removeServiceInstance,E as _serverApps,F as deleteApp,f as getApp,C as getApps,L as initializeApp,D as initializeServerApp,N as onLog,e as registerVersion,O as setLogLevel};
