import{i as f}from"./index3.js";export{f as default};
